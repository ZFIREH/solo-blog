title: SSH免密码登陆原理
date: '2019-05-26 22:12:18'
updated: '2019-05-26 22:12:48'
tags: [Linux]
permalink: /articles/2019/05/26/1558879938411.html
---
![](https://img.hacpai.com/bing/20190408.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

工作中，我们通常需要登录各种服务器，免密码登录无疑能大大的提高工作效率。以前只知道配置，今天了解了下原理。

免密码登录原理
![clipboard.png](https://img.hacpai.com/file/2019/05/clipboard-ab8b2633.png)


图解，server A免登录到server B:

1.在A上生成公钥私钥。

2.将公钥拷贝给server B，要重命名成authorized_keys(从英文名就知道含义了)

3.Server A向Server B发送一个连接请求。

4.Server B得到Server A的信息后，在authorized_key中查找，如果有相应的用户名和IP，则随机生成一个字符串，并用Server A的公钥加密，发送给Server A。

5.Server A得到Server B发来的消息后，使用私钥进行解密，然后将解密后的字符串发送给Server B。Server B进行和生成的对比，如果一致，则允许免登录。

总之：A要免密码登录到B，B首先要拥有A的公钥，然后B要做一次加密验证。对于非对称加密，公钥加密的密文不能公钥解开，只能私钥解开。