title: CentOS7开放端口
date: '2019-05-26 22:10:08'
updated: '2019-05-26 22:10:31'
tags: [Linux, 防火墙]
permalink: /articles/2019/05/26/1558879808476.html
---
![](https://img.hacpai.com/bing/20190323.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

[CentOS](http://www.linuxidc.com/topicnews.aspx?tid=14)升级到7之后，发现无法使用iptables控制Linuxs的端口，google之后发现Centos 7使用firewalld代替了原来的iptables。下面记录如何使用firewalld开放Linux端口：

开启端口
```
[root@zhouhuoc ~] firewall-cmd --zone=public --add-port=80/tcp --permanent
```
命令含义：

--zone #作用域

--add-port=80/tcp  #添加端口，格式为：端口/通讯协议

--permanent  #永久生效，没有此参数重启后失效

重新载入防火墙
```
[root@zhouhuoc ~]firewall-cmd --reload
```

  

关闭防火墙
```
#停止firewall
[root@zhouhuoc ~] systemctl stop firewalld.service 
#禁止firewall开机启动
systemctl disable firewalld.service 
```