title: MySQL安装之yum安装
date: '2019-05-26 21:52:13'
updated: '2019-05-26 22:22:25'
tags: [MySQL, CentOS7, Linux]
permalink: /articles/2019/05/26/1558878733328.html
---
![](https://img.hacpai.com/bing/20181002.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

在CentOS7中默认安装有MariaDB，这个是MySQL的分支，但为了需要，还是要在系统中安装MySQL，而且安装完成之后可以直接覆盖掉MariaDB。
## 1. 下载并安装MySQL官方的 Yum Repository
```
[root@zhouhuoc /]# wget -i -c http://dev.mysql.com/get/mysql57-community-release-el7-10.noarch.rpm
```
使用上面的命令就直接下载了安装用的Yum Repository;
```
[root@zhouhuoc /]# yum -y localinstallinstall mysql57-community-release-el7-10.noarch.rpm
```
使用yum安装MySQL;
```
[root@zhouhuoc /]# yum -y install mysql-community-server
```
## 2. MySQL数据库设置
编辑/etc/my.cnf配置文件
```
# For advice on how to change settings please see

# http://dev.mysql.com/doc/refman/5.7/en/server-configuration-defaults.html

[mysqld]
#
# Remove leading # and set to the amount of RAM for the most important data
# cache in MySQL. Start at 70% of total RAM for dedicated server, else 10%.
# innodb_buffer_pool_size = 128M
#
# Remove leading # to turn on a very important data integrity option: logging
# changes to the binary log between backups.
# log_bin
#
# Remove leading # to set options mainly useful for reporting servers.
# The server defaults are faster for transactions and fast SELECTs.
# Adjust sizes as needed, experiment to find the optimal values.
# join_buffer_size = 128M
# sort_buffer_size = 2M
# read_rnd_buffer_size = 2M

# 数据存放目录
datadir=/data/mysql
socket=/data/mysql/mysql.sock
#端口
port = 3308
#字符集
character_set_server = utf8
#表名忽略大小写
lower_case_table_names = 1

# Disabling symbolic-links is recommended to prevent assorted security risks
symbolic-links=0

log-error=/var/log/mysqld.log
pid-file=/var/run/mysqld/mysqld.pid

[client]
socket=/data/mysql/mysql.sock
```
启动MySQL
```
[root@zhouhuoc /]# systemctl start mysqld
```
查看mysql默认密码
```
[root@zhouhuoc /]# grep "password" /var/log/mysqld.log
```
![image.png](https://img.hacpai.com/file/2019/05/image-ebc80768.png)

登录到MySQL数据库
```
[root@zhouhuoc ~]# mysql -uroot -p
```
![image.png](https://img.hacpai.com/file/2019/05/image-b53e8386.png)
修改初始密码
```
mysql>  ALTER USER 'root'@'localhost' IDENTIFIED BY 'Abcd!234';
```
当密码过于简单时会报如下错误
![image.png](https://img.hacpai.com/file/2019/05/image-550bfbfb.png)
原因是因为MySQL有密码设置的规范，具体是与validate_password_policy的值有关：
![1072166201803151758587921817095409.png](https://img.hacpai.com/file/2019/05/1072166201803151758587921817095409-1c28d233.png)

MySQL完整的初始密码规则可以通过如下命令查看：
```
mysql> SHOW VARIABLES LIKE 'validate_password%';

+--------------------------------------+--------+
| Variable_name                        | Value  |
+--------------------------------------+--------+
| validate_password_dictionary_file    |        |
| validate_password_length             | 8      |
| validate_password_mixed_case_count   | 1      |
| validate_password_number_count       | 1      |
| validate_password_policy             | MEDIUM |
| validate_password_special_char_count | 1      |
+--------------------------------------+--------+
6 rows in set (0.00 sec)
```
 密码的长度是由validate_password_length决定的，而validate_password_length的计算公式是：
```
validate_password_length = validate_password_number_count + validate_password_special_char_count + (2 * validate_password_mixed_case_count)
```
解决方法就是修改密码为规范复杂的密码或者修改密码规则
```
mysql> set global validate_password_policy=0;

Query OK, 0 rows affected (0.00 sec)
 
mysql> set global validate_password_length=1;
Query OK, 0 rows affected (0.00 sec)
 
mysql>
```
卸载MySQL yum Repository
```
[root@zhouhuoc /]# yum -y remove mysql57-community-release-el7-10.noarch
```
开启MySQL远程登录权限
```
mysql> grant all on *.* to root@'%' identified by '数据库密码';

```
如果已开启防火墙，则开放端口或者关闭防火墙
* 关闭防火墙
```
[root@zhouhuoc /]# systemctl stop firewalld
[root@zhouhuoc /]# systemctl disablefirewalld
```
* 开放端口
```
[root@zhouhuoc /]# firewall-cmd --zone=public --add-port=80/tcp --permanent
[root@zhouhuoc /]# firewall-cmd --reload
```

引用自：[MySQL安装之yum安装](https://www.cnblogs.com/brianzhu/p/8575243.html)
